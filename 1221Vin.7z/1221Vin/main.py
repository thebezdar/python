import math
k=0
sum=0
a=float(input('Введите a'))
b=float(input('Введите b'))
h=float(input('Введите h'))
n=float(input('Введите n'))

while a<b:
    y=((a**2/4)+a/2+1)*math.e**(a/2)
    s=(k**2+1/math.factorial(k))*((a/2)**2)
    sum=sum+s
    print(f'y={y} s={s} sum={sum}')
    a+=1

