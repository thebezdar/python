# while True:
#     a = str(input('Введите плюс, минус, умножить или разделить'))
#     b = float(input('Введите число'))
#     c = float(input('Введите число'))
#     if a == ('плюс'):
#         print(b+c)
#     elif a == 'минус':
#         print(b - c)
#     elif a == 'умножить':
#         print(b * c)
#     elif a == 'разделить' and c!=0:
#        print (b/c)
#     elif c == 0:
#         print('На ноль делить нельзя')
#     elif a == '0':
#         print('Работа завершена')
#         break
#     else:
#         print('Вы ввели неправильное математическое действие')
